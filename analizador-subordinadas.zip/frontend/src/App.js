import React, { useState } from "react";
import Tree from "react-d3-tree";

function App() {
  const [sentence, setSentence] = useState("");
  const [treeData, setTreeData] = useState(null);

  const handleAnalyze = async () => {
    const response = await fetch("https://TU_API_URL/analizar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texto: sentence }),
    });

    const result = await response.json();
    const tree = convertirAArbol(result);
    setTreeData(tree);
  };

  const convertirAArbol = (tokens) => {
    const mapa = {};
    tokens.forEach((tok) => {
      mapa[tok.text] = { name: tok.text + ` (${tok.dep})`, children: [] };
    });

    let root = null;
    tokens.forEach((tok) => {
      if (tok.text === tok.head) {
        root = mapa[tok.text];
      } else {
        mapa[tok.head]?.children.push(mapa[tok.text]);
      }
    });

    return root ? [root] : null;
  };

  return (
    <div className="p-6">
      <h2>Analizador con Árbol Sintáctico</h2>
      <input
        type="text"
        value={sentence}
        onChange={(e) => setSentence(e.target.value)}
        placeholder="Escribe una oración..."
      />
      <button onClick={handleAnalyze}>Analizar</button>

      <div style={{ width: "100%", height: "500px" }}>
        {treeData && <Tree data={treeData} orientation="vertical" />}
      </div>
    </div>
  );
}

export default App;
from flask import Flask, request, jsonify
import spacy

app = Flask(__name__)
nlp = spacy.load("es_core_news_sm")

@app.route("/analizar", methods=["POST"])
def analizar():
    data = request.get_json()
    texto = data.get("texto", "")
    doc = nlp(texto)

    arbol = []
    for token in doc:
        arbol.append({
            "text": token.text,
            "dep": token.dep_,
            "head": token.head.text,
            "pos": token.pos_,
        })

    return jsonify(arbol)

if __name__ == "__main__":
    app.run(debug=True)